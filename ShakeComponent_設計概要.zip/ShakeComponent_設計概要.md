# MeshShakeComponent 設計概要

## 目的

インタラクト時に MeshComponent をガタガタと揺らす Component。
揺れの動きはアニメーターが作成したモーションデータを使用する。

## 背景と方針

- 対象メッシュはスケルトン構造が多様で数も膨大なため、AnimSequence をそのまま各メッシュで再生することはできない。
- そこで揺れを「スケルタルアニメーション」ではなく **単一トランスフォームの時系列データ** として扱う。
- アニメーターは DCC 上で **1 ボーンのロケータリグ** に揺れモーションを付けて FBX で納品する。
- エンジン側では共通のダミースケルトン用 AnimSequence としてインポートし、
  ランタイムでそのボーントラックを **直接サンプリング** して、対象 MeshComponent の
  RelativeTransform にオフセットとして適用する。
- 焼き込み(中間アセットへの変換)は行わない。納品された AnimSequence がそのまま最終アセットとなり、
  再インポートが即反映される。

## アセット規約

| 項目 | 内容 |
|---|---|
| リグ | 共通の 1 ボーンロケータリグ(全モーションで共有) |
| スケルトン | エンジン内の共通ダミースケルトン 1 つに集約 |
| 基準サイズ | 基準サイズ(例: 1m)のオブジェクト向けの振幅で作成する |
| 初期姿勢 | フレーム 0 は原点・無回転を推奨(そうでない場合もリファレンス差分で吸収する) |

## ランタイム設計

### 保持するデータ

- `UAnimSequence* ShakeAnim` : 揺れモーション(ダミースケルトン用)
- `float AmplitudeScale` : 振幅スケール(バウンズサイズからの自動算出オプションあり)
- `float PlayRate` : 再生速度
- 再インタラクト時ポリシー : Restart / Ignore(仕様に合わせて選択)

### 適用方法

- 揺れ適用前の RelativeTransform を **基準トランスフォーム** として保持する。
- 毎フレーム `基準 × 揺れオフセット` を RelativeTransform にセットする。
- 再生終了時に基準へ戻す。
- 対象が移動するオブジェクトの場合、基準が古くなるため、
  中継用 SceneComponent を挟む、または毎フレーム基準を取り直す構造を検討する。

### サンプリング

- `UAnimSequence::GetBoneTransform`(または相当 API)で、経過時間を時刻として
  揺れボーンのトランスフォームを評価する。
- フレーム 0(またはリファレンスポーズ)のトランスフォームを起点として差分化し、
  オフセットのみを使用する。
- 1 ボーンのみの評価なのでコストは実用上無視できる。

## 疑似コード

```cpp
// C++ 風疑似コード。API 名は目安であり、実際のエンジンバージョンに合わせること。

class UMeshShakeComponent : public UActorComponent
{
    // --- 設定 ---
    UAnimSequence* ShakeAnim;        // 揺れモーション(ダミースケルトン用)
    float AmplitudeScale = 1.0f;     // 振幅スケール
    bool bScaleByBounds = false;     // バウンズサイズで振幅を正規化するか
    float PlayRate = 1.0f;
    ERestartPolicy RestartPolicy;    // Restart / Ignore

    // --- 状態 ---
    UMeshComponent* TargetMesh;      // 揺らす対象
    FTransform BaseTransform;        // 揺れ適用前の RelativeTransform
    FTransform RefOffsetInv;         // リファレンス(フレーム0)姿勢の逆変換
    float ElapsedTime = 0.0f;
    bool bPlaying = false;

    void Initialize(UMeshComponent* InTarget)
    {
        TargetMesh = InTarget;

        // フレーム0 の姿勢を取得し、逆変換をキャッシュしておく
        FTransform RefPose = SampleShakeBone(/*Time=*/0.0f);
        RefOffsetInv = RefPose.Inverse();

        if (bScaleByBounds)
        {
            // 基準サイズ 1m 前提。対象バウンズとの比で振幅を補正
            float Size = TargetMesh->Bounds.SphereRadius * 2.0f;
            AmplitudeScale *= Size / 100.0f;   // 100cm = 基準 1m
        }
    }

    // インタラクト時に呼ぶ
    void Play()
    {
        if (bPlaying && RestartPolicy == Ignore)
            return;

        if (!bPlaying)
            BaseTransform = TargetMesh->GetRelativeTransform(); // 揺れ前を保存

        ElapsedTime = 0.0f;
        bPlaying = true;
        SetComponentTickEnabled(true);
    }

    void TickComponent(float DeltaTime)
    {
        if (!bPlaying)
            return;

        ElapsedTime += DeltaTime * PlayRate;

        if (ElapsedTime >= ShakeAnim->GetPlayLength())
        {
            Stop();
            return;
        }

        // 1) 揺れボーンを時刻評価
        FTransform Sampled = SampleShakeBone(ElapsedTime);

        // 2) リファレンス差分化(フレーム0 を単位とするオフセットに変換)
        FTransform Offset = RefOffsetInv * Sampled;

        // 3) 振幅スケール(位置のみ。回転はそのまま使う)
        Offset.ScaleTranslation(AmplitudeScale);

        // 4) 基準 × オフセット を適用
        TargetMesh->SetRelativeTransform(Offset * BaseTransform);
    }

    void Stop()
    {
        bPlaying = false;
        TargetMesh->SetRelativeTransform(BaseTransform);  // 基準へ戻す
        SetComponentTickEnabled(false);
    }

    // AnimSequence から揺れボーン(トラック0想定)を直接サンプリング
    FTransform SampleShakeBone(float Time)
    {
        // UE5 系: GetBoneTransform / データモデル経由の評価 API を使用
        // 圧縮・補間込みの最終結果が得られる評価系 API を推奨
        FTransform Out;
        ShakeAnim->GetBoneTransform(Out, /*TrackIndex=*/0, Time, /*bUseRawData=*/false);
        return Out;
    }
};
```

## 実装上の注意

- **RelativeTransform の競合**: 他システムが対象の RelativeTransform を書き換える場合は
  競合する。必要なら揺れ専用の中継 SceneComponent を親に挟み、そちらだけを揺らす。
- **移動するオブジェクト**: 再生中に対象が移動・再アタッチされると `BaseTransform` が
  古くなる。対象が静的配置物のみなら現状の構造で問題ない。
- **評価 API**: `GetBoneTransform` 相当の API はエンジンバージョンにより異なる。
  圧縮データに対する評価(bUseRawData=false 相当)を使うこと。
- **クック**: ダミースケルトンと AnimSequence がクックに含まれる。1 ボーンなので
  サイズは軽微。
- **再インタラクト仕様**: Restart / Ignore のどちらにするかは仕様確定が必要。
  加算(重ね掛け)は複雑化するため現状スコープ外。

## アニメーター向けフロー

1. 共通ロケータリグに揺れモーションを作成(基準サイズ規約に従う)
2. FBX で納品
3. 共通ダミースケルトン指定でインポート(以降の変換作業なし)
4. バリエーション追加も同じリグの使い回しで完結
