# BoneAnimApplierComponent 仕様書

## 概要

AnimSequence 内の特定ボーンのアニメーション(位置・回転)を、
別スケルトンの SkeletalMesh の指定ボーンに適用するためのコンポーネント。

ターゲットの SkeletalMeshComponent は自身の AnimBP で通常のアニメーションを
再生している前提とし、本コンポーネントは「サンプリングした Transform を公開する」
役割に徹する。実際のボーンへの書き込みはターゲット側 AnimBP の
`Transform (Modify) Bone` ノードが行う。

## 前提・制約

- ソースとターゲットのスケルトンは異なってよい
- 対象ボーンは 1 組のみ(ソースボーン名 → ターゲットボーン名)
- 適用要素は **位置と回転**(スケールは無視)
- 再生はループなし。AnimSequence の終端に達したら自動終了
- リターゲット補正は行わない
  - `GetBoneTransform()` で得られる親相対 Transform をそのまま適用する
  - リファレンスポーズの差により見た目がずれる可能性は許容する

## クラス構成

- クラス名: `UBoneAnimApplierComponent`
- 基底クラス: `UActorComponent`
- Tick: 有効(再生中のみ処理)

## プロパティ(エディタ設定)

| 名前 | 型 | 説明 |
|---|---|---|
| SourceSequence | UAnimSequence* | サンプリング元の AnimSequence |
| SourceBoneName | FName | サンプリング対象のボーン名(ソーススケルトン側) |
| TargetBoneName | FName | 適用先のボーン名(ターゲットスケルトン側)※AnimBP 側の参照用 |

## 公開する状態(AnimBP から参照)

| 名前 | 型 | 説明 |
|---|---|---|
| bIsPlaying | bool | 再生中フラグ。AnimBP 側で Alpha に使用する |
| SampledTransform | FTransform | サンプリング結果(親相対空間、位置・回転のみ有効) |

## 公開関数

| 名前 | 説明 |
|---|---|
| Play() | BlueprintCallable。再生を開始する。再生時間を 0 にリセットする |

## 疑似コード

```
class UBoneAnimApplierComponent : UActorComponent

    // 設定
    SourceSequence : AnimSequence
    SourceBoneName : Name
    TargetBoneName : Name

    // 状態
    bIsPlaying       : bool      = false
    SampledTransform : Transform = Identity
    CurrentTime      : float     = 0

    function Play():
        if SourceSequence == null:
            return
        if SourceSequence にボーン SourceBoneName が存在しない:
            警告ログを出して return
        CurrentTime = 0
        bIsPlaying = true
        SampleAtCurrentTime()   // 開始フレームを即時反映

    function Tick(DeltaTime):
        if not bIsPlaying:
            return

        CurrentTime += DeltaTime

        if CurrentTime >= SourceSequence.GetPlayLength():
            // 終端。最終フレームは適用せず終了する場合はここで止める。
            // 最終フレームを反映したい場合は
            // CurrentTime を PlayLength にクランプして 1 回サンプリング後に止める
            Stop()
            return

        SampleAtCurrentTime()

    function SampleAtCurrentTime():
        // 指定時刻の親相対(Bone Space)Transform を取得
        // C++ 実装時は UAnimSequence::GetBoneTransform(
        //     OutTransform, BoneTrackIndex, Time, bUseRawData) 相当の API を使用
        SampledTransform = SourceSequence.SampleBoneTransform(
                               SourceBoneName, CurrentTime)
        // スケールは使用しないため単位スケールに正規化しておく
        SampledTransform.Scale = (1, 1, 1)

    function Stop():
        bIsPlaying = false
        // SampledTransform は保持したままでよい
        // (Alpha = 0 になるため参照されない)
```

## ターゲット側 AnimBP の設定(利用手順)

1. AnimGraph に `Transform (Modify) Bone` ノードを 1 つ追加する
2. ノード設定:
   - Bone to Modify: コンポーネントの `TargetBoneName` と同じボーン
   - Translation Mode: **Replace**
   - Rotation Mode: **Replace**
   - Scale Mode: **Ignore**
   - Translation Space / Rotation Space: **Bone Space(親相対)**
3. Event Graph(または Property Access)でコンポーネントを取得し、
   毎フレーム以下を反映する:
   - Translation ← `SampledTransform` の位置
   - Rotation    ← `SampledTransform` の回転
   - Alpha       ← `bIsPlaying` を 1.0 / 0.0 に変換した値
4. `bIsPlaying` が false のとき Alpha が 0 になり、
   元のアニメーションに自動復帰する

## 終了時の挙動

- シーケンス終端に達したら `bIsPlaying = false`
- AnimBP 側の Alpha が 0 になることで `Transform (Modify) Bone` が無効化され、
  ターゲットは元のアニメーションに復帰する
- Alpha の急変によるポップが問題になる場合、Alpha の補間は
  AnimBP 側の責務とする(本コンポーネントでは行わない)

## 実装上の注意

- `GetBoneTransform()` はソーススケルトンにおける **親相対** Transform を返す。
  ターゲット側も Bone Space(親相対)で適用することで空間を一致させる
- ソースボーン名がシーケンスに存在しない場合は `Play()` 時に警告を出して
  再生しない
- Tick はエディタプレビューでは動作しないため、動作確認は PIE で行う
