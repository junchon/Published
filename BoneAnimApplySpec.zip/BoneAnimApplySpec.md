# ボーンアニメーション適用コンポーネント 仕様書

## 概要

AnimSequence 内の特定ボーンのアニメーション(位置・回転)を、
別スケルトンの SkeletalMesh の指定ボーンに適用するためのコンポーネント。

ターゲットの SkeletalMeshComponent は自身の AnimBP で通常のアニメーションを
再生している前提とし、本コンポーネントは「サンプリングした Transform を公開する」
役割に徹する。実際のボーンへの書き込みはターゲット側 AnimBP の
`Transform (Modify) Bone` ノードが行う。

## 前提・制約

- ソースとターゲットのスケルトンは異なってよい
- 対象ボーンは 1 本のみ
- 適用要素は **位置と回転**(スケールは無視)
- 適用方式は **Add(加算)固定**
  - 公開する Transform は絶対ポーズではなく **デルタ(差分)**
  - デルタの基準は **先頭フレーム(t=0)**。開始時のデルタは単位 Transform に
    なるため、発動時にポップしない
- 再生はループなし。AnimSequence の終端に達したら自動終了
- リターゲット補正は行わない
  - 終端到達時はデルタが残った状態で Alpha が 0 になるため、終端の
    ポップ吸収は AnimBP 側の Alpha 補間の責務とする

## クラス構成

- 基底クラス: `UActorComponent`
- Tick: 再生中のみ有効化する
  - 初期状態では Tick を無効にしておき、`Play()` で有効化、終了時(`Stop()`)に
    無効化する

## プロパティ(エディタ設定)

| 名前 | 型 | 説明 |
|---|---|---|
| SourceSequence | UAnimSequence* | サンプリング元の AnimSequence |
| SourceBoneName | FName | サンプリング対象のボーン名(ソーススケルトン側) |

## 公開する状態(AnimBP から参照)

| 名前 | 型 | 説明 |
|---|---|---|
| bIsPlaying | bool | 再生中フラグ。AnimBP 側で Alpha に使用する |
| DeltaTransform | FTransform | 先頭フレーム基準のデルタ(親相対空間、位置・回転のみ有効) |

## 公開関数

| 名前 | 説明 |
|---|---|
| Play() | BlueprintCallable。再生を開始する。再生時間を 0 にリセットする |

## 疑似コード

```
class ボーンアニメーション適用コンポーネント : UActorComponent

    // 設定
    SourceSequence : AnimSequence
    SourceBoneName : Name

    // 状態
    bIsPlaying         : bool      = false
    DeltaTransform     : Transform = Identity
    FirstFramePose     : Transform = Identity   // t=0 のポーズ(基準)
    CurrentTime        : float     = 0

    function Play():
        if SourceSequence == null:
            return
        if SourceSequence にボーン SourceBoneName が存在しない:
            警告ログを出して return
        CurrentTime = 0
        // 基準となる先頭フレームのポーズを取得して保持
        FirstFramePose = SourceSequence.SampleBoneTransform(SourceBoneName, 0)
        DeltaTransform = Identity   // 開始時のデルタは必ず単位 Transform
        bIsPlaying = true
        SetComponentTickEnabled(true)

    function Tick(DeltaTime):
        if not bIsPlaying:
            return

        CurrentTime += DeltaTime

        if CurrentTime >= SourceSequence.GetPlayLength():
            // 終端。最終フレームは適用せず終了する場合はここで止める。
            // 最終フレームを反映したい場合は
            // CurrentTime を PlayLength にクランプして 1 回サンプリング後に止める
            Stop()
            return

        SampleAtCurrentTime()

    function SampleAtCurrentTime():
        // 指定時刻の親相対(Bone Space)Transform を取得
        // C++ 実装時は UAnimSequence::GetBoneTransform(
        //     OutTransform, BoneTrackIndex, Time, bUseRawData) 相当の API を使用
        CurrentPose = SourceSequence.SampleBoneTransform(
                          SourceBoneName, CurrentTime)

        // 先頭フレームからのデルタを計算
        // 回転: 基準の逆回転を合成してデルタクォータニオンを得る
        DeltaTransform.Rotation =
            Inverse(FirstFramePose.Rotation) * CurrentPose.Rotation
        // 位置: 単純な差分ベクトル
        DeltaTransform.Translation =
            CurrentPose.Translation - FirstFramePose.Translation
        // スケールは使用しない
        DeltaTransform.Scale = (1, 1, 1)

    function Stop():
        bIsPlaying = false
        SetComponentTickEnabled(false)
        // DeltaTransform は保持したままでよい
        // (Alpha = 0 になるため参照されない)
```

## ターゲット側 AnimBP の設定(利用手順)

1. AnimGraph に `Transform (Modify) Bone` ノードを 1 つ追加する
2. ノード設定:
   - Bone to Modify: アニメーションを適用したいボーンを指定
   - Translation Mode: **Add**
   - Rotation Mode: **Add**
   - Scale Mode: **Ignore**
   - Translation Space / Rotation Space: **Bone Space(親相対)**
3. Event Graph(または Property Access)でコンポーネントを取得し、
   毎フレーム以下を反映する:
   - Translation ← `DeltaTransform` の位置
   - Rotation    ← `DeltaTransform` の回転
   - Alpha       ← `bIsPlaying` を 1.0 / 0.0 に変換した値
4. `bIsPlaying` が false のとき Alpha が 0 になり、
   元のアニメーションに自動復帰する

## 終了時の挙動

- シーケンス終端に達したら `bIsPlaying = false`
- AnimBP 側の Alpha が 0 になることで `Transform (Modify) Bone` が無効化され、
  ターゲットは元のアニメーションに復帰する
- Alpha の急変によるポップが問題になる場合、Alpha の補間は
  AnimBP 側の責務とする(本コンポーネントでは行わない)

## 実装上の注意

- `GetBoneTransform()` はソーススケルトンにおける **親相対** Transform を返す。
  ターゲット側も Bone Space(親相対)で適用することで空間を一致させる
- 公開するのは絶対ポーズではなく **先頭フレーム基準のデルタ**。
  Add モードで加算されるため、ターゲットの既存アニメーションに
  「ソースシーケンス内の動き」だけが上乗せされる
- 回転デルタの計算順序に注意(基準の逆回転 × 現在の回転)。
  順序を誤ると回転軸がずれる
- ソースボーン名がシーケンスに存在しない場合は `Play()` 時に警告を出して
  再生しない
- Tick はエディタプレビューでは動作しないため、動作確認は PIE で行う
